package program;
public class Supplier {
	Product[] productsArr ;
	public Supplier(Product[] productsArr) {
		this.productsArr=productsArr;
	}
}
