package presentation;

import java.io.IOException;

import domain.Menu;

public class VehiclePriceCalculatorApp {
	public static void main(String[] args) throws IOException {
	Menu.application();
		

	}

}
